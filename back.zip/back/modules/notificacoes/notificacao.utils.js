

export const ATRIBUTOS_NOTIFICACAO =
    [
        'titulo',
        'remetenteCod',
        'remetenteNome',
        'descricacao',
        'destinatario',
        'status',
        'curso',
        'disciplina'
    ]