
/* TODO - implementar a busca por outros atributos */
export const ATRIBUTOS_SEMESTRE =
    ['titulo', 'dataFechamento', 'status']