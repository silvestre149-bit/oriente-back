

export const ATRIBUTOS_PARTICIPACAO =
    [
        'tipo',
        'usuarioId',
        'semestreId',
        'projetoId',
        'componente',
        'turma',
        'ambosTcc',
        'curso',
        'disciplina'
    ]