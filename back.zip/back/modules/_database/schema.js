/* configurações em comum para todos os schemas, como data de atualização */
export const schemaOptionsBase = {
    timestamps: true
}