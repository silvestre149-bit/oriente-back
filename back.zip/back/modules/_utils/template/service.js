export default class Service {
    static async buscarTodos() { }
    static async buscarUm(id) { }
    static async criar(objeto) { }
    static async atualizar(id, objeto) { }
    static async deletar(id) { }
}