
/**
 * @param {import("express").Request} req 
 * @param {import("express").Response} res 
 */
export async function buscarUm(req, res) { }

export async function buscarTodos(req, res) { }

export async function criar(req, res) { }

export async function atualizar(req, res) { }

export async function deletar(req, res) { }


