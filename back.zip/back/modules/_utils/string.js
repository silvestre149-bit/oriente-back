
/**
 * 
 * @param {String} texto 
 */
export function acrescentarVirgula(texto) {
    return texto.length > 0
}