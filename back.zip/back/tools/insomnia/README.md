
# Requisições no insomnia

para utilizar basta importar o arquivo